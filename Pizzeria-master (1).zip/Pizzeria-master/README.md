# Pizzeria
A pizza ordering system made using Java and SQLite in android studio (native)

The APK is also included for mobile installation
